from setuptools import setup

setup(
    name="gestion_biblioteca",
    version="1.0",
    description= "Paquete de gestion de biblioteca",
    author="Daniel floriano",
    author_email ="danielflorianoblanco@gmail.com",
    url="http://www.creationbcn.com",
    packages = ["funciones"],
    scripts =[]
)