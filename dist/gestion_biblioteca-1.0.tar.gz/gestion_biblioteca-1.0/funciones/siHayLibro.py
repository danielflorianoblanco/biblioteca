def sihaylibro(lista_libros):
    listaVacia = len(lista_libros)
    
    if listaVacia == False:
        print("No hay libros")
        
    else:
        pass

    return listaVacia